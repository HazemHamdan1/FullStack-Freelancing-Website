import React from 'react';
import Navbar from "./components/Navbar/Navbar.jsx";
import Footer from './components/Footer/Footer.jsx';
import Home from './pages/home/Home.jsx'
import MyGigs from './pages/myGigs/MyGigs.jsx';
import Gigs from './pages/gigs/Gigs.jsx'
import Gig from './pages/gig/Gig.jsx'
import Message from './pages/message/Message.jsx'
import Messages from './pages/messages/Messages.jsx'
import Add from './pages/add/Add.jsx'
import Order from './pages/order/Order.jsx'
import Login from './pages/log in/logIn.jsx';
import Register from './pages/register/Register.jsx';
import Success from './pages/success/success.jsx'
import Pay from './pages/pay/Pay.jsx';
import './App.scss'
import {
  QueryClient,
  QueryClientProvider,
  useQuery,
} from '@tanstack/react-query'
import {
  createBrowserRouter,
  RouterProvider,
  Outlet,
} from "react-router-dom";

const queryClient = new QueryClient()
function Layout() {
  return (
    <div className="app">
      <QueryClientProvider client={queryClient}>
        <Navbar />
        <Outlet />
        <Footer />
      </QueryClientProvider>
    </div>
  );
}

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      children: [
        {
          path: '/',
          element: <Home />
        },
        {
          path: '/gigs',
          element: <Gigs />
        },
        {
          path: '/gig/:id',
          element: <Gig />
        },
        {
          path: '/order',
          element: <Order />
        },
        {
          path: '/myGigs',
          element: <MyGigs />
        },
        {
          path: '/messages',
          element: <Messages />
        },
        {
          path: '/message/:id',
          element: <Message />
        },
        {
          path: '/add',
          element: <Add />
        },
        {
          path:'/login',
          element: <Login/>
        },
        {
          path:'/register',
          element: <Register/>
        },
        {
          path:'/pay/:id',
          element: <Pay />
        },
        {
          path:'/success',
          element: <Success />
        }
      ]
    },
  ]);
  return (
    <div>
      <RouterProvider router={router} />
    </div>
  )
}

export default App;