export const cards=[
    {
        id:1,
        title:"FrontEnd",
        desc:"Add great FrontEnd to your site",
        img:"./cards/front.jpg"
    },
    {
        id:2,
        title:"BackEnd",
        desc:"Make your site felxiple",
        img:"./cards/back.jpg"
    },
    {
        id:3,
        title:"LogoDesign",
        desc:"Best logo for your business",
        img:"./cards/logo.jpg"
    },
    {
        id:4,
        title:"DataAnalyst",
        desc:"Squiz your data for best Insits",
        img:"./cards/data.jpg"
    },
    {
        id:5,
        title:"Photoshop",
        desc:"Take the a shoot for the best of you",
        img:"./cards/photo.jpg"
    },
    {
        id:6,
        title:"CopyWrite",
        desc:"Huge Viewers by writing",
        img:"./cards/copy.jpg"
    }
]

export const gigs=[
    {
        id:1,
        img:"./s.jpg",
        pp:"./h.png",
        desc:"",
        price:100,
        star:5,
        username:""
    },
    {
        id:2,
        img:"./s.jpg",
        pp:"./h.png",
        desc:"",
        price:100,
        star:5,
        username:""
    },
    {
        id:3,
        img:"./s.jpg",
        pp:"./h.png",
        desc:"",
        price:100,
        star:5,
        username:""
    }
]