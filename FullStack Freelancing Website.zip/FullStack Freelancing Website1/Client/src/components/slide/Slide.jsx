import './Slide.scss'
import React from 'react';
import Slider from 'infinite-react-carousel';

export default function Slide({children,slidesToShow,arrowsScroll}) {
  return (
    <div className='Slide'>
      <div className="container">
      <Slider slidesToShow={slidesToShow} arrowsScroll={arrowsScroll}>
    {children}
  </Slider>
      </div>
    </div>
  )
}
