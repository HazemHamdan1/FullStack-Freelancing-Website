import './catCard.scss'
import { Link } from 'react-router-dom'
import React from 'react'

export default function catCard({item}) {
  return (
    <Link to={"/gigs?cat="+item.title}>
      <div className='catCard'>
        <img src={item.img} alt="Not Found" />
        <span className='desc'>{item.desc}</span>
        <span className='title'>{item.title}</span>
      </div>
      
    </Link>
  )
}
 