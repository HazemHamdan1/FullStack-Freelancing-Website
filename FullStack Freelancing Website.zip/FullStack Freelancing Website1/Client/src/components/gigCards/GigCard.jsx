import React, { useState,useEffect } from 'react'
import './GigCard.scss'
import { Link } from 'react-router-dom'
import { useQuery } from "@tanstack/react-query";
import newRequest from "../../utils/newRequest";

export default function GigCard({item}) {

const {
  isLoading: isLoading,
  error: error,
  data: user,
} = useQuery({
  queryKey: ["user"],
  queryFn: async() =>
   await newRequest.get(`/users/${item.userId}`).then((res) => {
      return  res.data;
    }),
  enabled: !!item.userId,
});
 
const currentUser= JSON.parse( localStorage.getItem("currentUser"));


  return (
    <div className='gigCard'>
      <Link to={`/gig/${item._id}`} className='link'>
        <img src={item.img} alt="" />
        <div className="info">
        {isLoading ? (
          "loading"
          ) : error ? (
            "Something went wrong!"
            ) : (
              <div className="user">
            <img src="/no-avatar.png" alt="" />
            <span>{user.username}</span>
          </div>
          )}
            <p>{item.desc}</p>
        </div>
            </Link>
        <hr />
        <div className="details">
          <div className="price">
            <span>STARTING AT :</span>
            <h2>${item.price}</h2>
          </div>
        </div>
    </div>
  )
}
