import React, { useState } from 'react'
import { Link, Navigate } from 'react-router-dom';
import newRequest from '../../utils/newRequest.js'
import { useNavigate } from "react-router-dom";
import './Navbar.scss'
export default function navnar() {
  const currentUser= JSON.parse( localStorage.getItem("currentUser"));

  const Navigate = useNavigate();

  const handleLogout=async()=>{
    try{
      await newRequest.post('/auth/logout')
      localStorage.setItem('currentUser',null)
      Navigate("/")
    }catch(err){
      console.log(err)
    }
  };
  const [Open,setOpen]=useState(false);
  
  return (
    <div className='nevbar'>
      <div className="container">
      <div className="logo">
        <Link to="/" className='link'>
          <span className='c'>"</span>
          <span className='text'>Ideal Code</span>
          <span className='c'>"</span>

        </Link>
       
        </div>
        <div className="links">
          <span>English</span>
          {!currentUser &&<Link className='link' to='/login'><span>log In</span></Link>}
        
          {!currentUser && <Link to={"/register"} className='link'><button >Join</button></Link>}

          {currentUser && (<div className="user" onClick={()=>setOpen(!Open)}>
          <img src={currentUser.img || "/no-avatar.png"} 
          alt=" Personal Image" />
          <span>{currentUser.username}</span>
          {Open &&<div className="options">
            {currentUser.isSeller && (
            <>
            <Link className='link' to='/myGigs'>Gigs</Link >
            <Link className='link' to='Add'>Add Gig</Link > 
            </>
            )}
            <Link className='link' to='/Order'>Order</Link >
            <Link className='link' to='/Messages'>Messages</Link >
            <Link className='link' onClick={handleLogout} >LogOut</Link >
          </div>}
          </div>)}
        </div>

      </div>
      </div>
  )
}
