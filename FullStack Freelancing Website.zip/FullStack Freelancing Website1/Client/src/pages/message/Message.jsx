import React from 'react'
import './Message.scss'
import { Link, useParams } from 'react-router-dom'
import newRequest from "../../utils/newRequest";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export default function Message() {

const { id } = useParams();
const currentUser = JSON.parse(localStorage.getItem("currentUser"));

const queryClient = useQueryClient();

const { isLoading, error, data } = useQuery({
  queryKey: ["messages"],
  queryFn: () =>
    newRequest.get(`/messages/${id}`).then((res) => {
      return res.data;
    }),
});

const mutation = useMutation({
  mutationFn: (message) => {
    return newRequest.post(`/messages`, message);
  },
  onSuccess: () => {
    queryClient.invalidateQueries(["messages"]);
  },
});

const handleSubmit = (e) => {
  e.preventDefault();
  mutation.mutate({
    convId: id,
    desc: e.target[0].value,
  });
  e.target[0].value = "";
};
console.log(data)
  return (
    <div className='message'>
      <div className="container">
        <span className='breadcrumbs'>
          <Link to='/messages'>Messages</Link> {" > "}{currentUser.username}{" > "}
        </span>
       {isLoading ? (
          "loading"
        ) : error ? (
          "error"
        ) : ( <div className="messages">
          {data?.map((m)=>(
          <div className={m.userId === currentUser._id ? "owner item" : "item"} key={m._id}>
            <img src="/no-avatar.png" alt="" />
            <p>{m.desc}</p>
          </div>
          ))}
        </div>)}
      
        <form className="write" onSubmit={handleSubmit}>
          <textarea name="" id="" placeholder='write a message' cols="30" rows="10"></textarea>
          <button  type='submit'>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
            <path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576 6.636 10.07Zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z"/>
            </svg> Send
          </button>
        </form>
      </div>
    </div>
  )
}
