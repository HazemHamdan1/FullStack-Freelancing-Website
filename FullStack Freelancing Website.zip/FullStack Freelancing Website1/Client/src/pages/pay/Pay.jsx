import React, { useEffect } from "react";
import { Link ,useNavigate} from "react-router-dom";
import "./Pay.scss";
import { useQuery } from "@tanstack/react-query";
import newRequest from "../../utils/newRequest";
import { useParams } from "react-router-dom";
//import { loadStripe } from "@stripe/stripe-js";
//import { Elements } from "@stripe/react-stripe-js";
//import CheckoutForm from "../../components/checkoutForm/CheckoutForm";

function Pay() {

  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading, error, data } = useQuery({
    queryKey: ["gig"],
    queryFn: async() =>
     await newRequest.get(`/gigs/single/${id}`).then((res) => {
        return res.data;
      }),
  });

  const userId = data?.userId;

  const {
    isLoading: isLoadingUser,
    error: errorUser,
    data: user,
  } = useQuery({
    queryKey: ["user"],
    queryFn: async() =>
     await newRequest.get(`/users/${userId}`).then((res) => {
        return  res.data;
      }),
    enabled: !!userId,
  });

  const makeRequest = async () => {
    try {
      const res = await newRequest.post(
        `/orders/${id}`
      );
      
    } catch (err) {
      console.log(err);
    }
  };
  
  return (
    <div className="payment-container">
      
      <h2>Enter your payment info</h2>
      <form className="payment-form">
        <label htmlFor="cardNumber">Card Number</label>
        <input type="text" id="cardNumber" />

        <label htmlFor="expiryDate">Expiry Date</label>
        <input type="text" id="expiryDate" />

        <label htmlFor="cvv">CVV</label>
        <input type="text" id="cvv" />

        <Link to='/success'>
          <button className = 'button' onClick={() => makeRequest()}>Pay Now</button>
        </Link>
      </form>
    </div>
  );
}

export default Pay;
