import React, { useEffect } from "react";
import './success.scss';
import { useLocation, useNavigate } from "react-router-dom";

const Success = () => {

  const navigate = useNavigate();


  useEffect(() => {
    const makeRequest = async () => {
      try {
        setTimeout(() => {
          navigate("/order");
        }, 3000);
      } catch (err) {
        console.log(err);
      }
    };

    makeRequest();
  }, []);


  return (
    <div className="success">
      <h1>Payment Successful !!</h1>
      <p className='thanks'>Thank you for your purchase.</p>
      <p className='note'>Redirecting you to the order page ....</p>
    </div>
  );
};

export default Success;
