import React from 'react'
import './Gig.scss'
import {Slider} from 'infinite-react-carousel';
import { useQuery } from "@tanstack/react-query";
import newRequest from "../../utils/newRequest";
import { Link, json, useParams } from "react-router-dom";
export default function Gig() {
  const { id } = useParams();
  const currentUser= JSON.parse( localStorage.getItem("currentUser"));
  const { isLoading, error, data } = useQuery({
    queryKey: ["gig"],
    queryFn: async() =>
     await newRequest.get(`/gigs/single/${id}`).then((res) => {
        return res.data;
      }),
  });

  const userId = data?.userId;

  const {
    isLoading: isLoadingUser,
    error: errorUser,
    data: user,
  } = useQuery({
    queryKey: ["user"],
    queryFn: async() =>
     await newRequest.get(`/users/${userId}`).then((res) => {
        return  res.data;
      }),
    enabled: !!userId,
  });
  
  const makeRequest = async () => {
    try {
      const res = await newRequest.post(
        `/orders/${id}`
      );
    } catch (err) {
      console.log(err);
    }
  };
  
  


  return (
    <div className='gig'>
      {isLoading ? (
      "loading"
      ) : error ? (
        "Something went wrong!"
      ) : (
      <div className="container">
        <div className="left">
          <span className="breadCrumbs">Idael Code {">"} {data?.cat}</span>
          <h1>{data.cat}</h1>

          <div className="user">
            <img className='pp' src="/no-avatar.png" alt="" />
            <span>{user?.username}</span>

          </div>
          <Slider className="slider" slidersToShow={1} arrowsScroll={1}>
            <img src={data.img} alt="" />
            <img src={data.img} alt="" />
            <img src={data.img} alt="" />
          </Slider>
          <h2>About the Gig : </h2>
          <p>{data.desc}</p>

        </div>

        <div className="right">
          <div className="price">
            <h3> {data.shortTitle}</h3>
            <h2>price : {data.price}$</h2>
          </div>
            <p>
              {data.shortDesc}
            </p>
            <div className="details">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clock-fill" viewBox="0 0 16 16">
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71V3.5z"/>
            </svg>
            <span>{data.deliveryTime} days</span>
            </div>
            {!currentUser.isSeller && <Link to={`/pay/${id}`}>
              <button onClick={() => makeRequest()}>Continue</button>
            </Link>}
        </div>
      </div>
      )}
    </div>
  )
}
