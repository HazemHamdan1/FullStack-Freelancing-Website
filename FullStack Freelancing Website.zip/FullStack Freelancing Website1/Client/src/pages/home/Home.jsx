import React from 'react'
import './Home.scss'
import Featured from '../../components/featured/Featured'
import Slide from '../../components/slide/Slide' 
import CatCard from '../../components/catCard/catCard'
import {cards} from '../../data'
export default function Home() {
  return (
    <div className='home'>
      <Featured/>
      <Slide slidesToShow={3} arrowsScroll={3}>
      {cards.map(card=>(
      <CatCard item={card} key={card.id}/>
    ))}
      </Slide>
      <div className="features">
        <div className="container">
          <div className="item">
             <h1>All great talents between your hands</h1>  
             <div className="title">Fast Work </div>
             <p>Hire fast and geat coders for
               your work.
              </p>
              <div className="title">Low Budget </div>
             <p>Hight quality with low paying.
              </p><div className="title">Flexiplity </div>
             <p>Flexiple project by chating with
               your freelancer.
              </p><div className="title">High Quality </div>
             <p>Great for Big and Samll businesses.
              </p>
              
          </div>
          <div className="img">
            <img src="./code.png" alt="" height={400} />
          </div>
        </div>
      </div>
      <hr />
    </div>
  )
}
