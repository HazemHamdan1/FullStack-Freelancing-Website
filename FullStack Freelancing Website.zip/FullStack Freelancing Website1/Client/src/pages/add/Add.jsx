import React, { useReducer, useState } from "react";
import "./Add.scss";
import { gigReducer, INITIAL_STATE } from "../../reducers/gigReducer";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import newRequest from "../../utils/newRequest";
import { useNavigate } from "react-router-dom";

export default function Add() {
const [file,setFile]=useState(null)
const [uploading, setUploading] = useState(false);
const [state, dispatch] = useReducer(gigReducer, INITIAL_STATE);

  const handleChange = (e) => {
    dispatch({
      type: "CHANGE_INPUT",
      payload: { name: e.target.name, value: e.target.value },
    });
  };
 
  const navigate = useNavigate();

  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (gig) => {
      return newRequest.post("/gigs", gig);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["myGigs"]);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(state);
    navigate("/mygigs")
  };
  const handleUpload = async () => {
    setUploading(true);
    try {
      const image = '/'+file.name
      setUploading(false);
      dispatch({ type: "ADD_IMAGE", payload: { image } });
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div className='add'>
      <div className="container">
        <h1>add Gig</h1>
        <div className="sections">
          <div className="left">
            <label htmlFor="title"> Title </label>
            <input 
            type="text" 
            name='Title' 
            placeholder='Write the Title'
            onChange={handleChange}
             />

            <label htmlFor="cats" >Cagtegory</label>
            <select name="cat" id="cat" onChange={handleChange}>
              <option value="FrontEnd">FrontEnd</option>
              <option value="BackEnd">BackEnd</option>
              <option value="LogoDesign">LogoDesign</option>
              <option value="Photoshop">Photoshop</option>
              <option value="DataAnalyst">DataAnalysis</option>
              <option value="CopyWrite">CopyWrite</option>
            </select>

            <label htmlFor="">Upload Image</label>
            <input  type="file" name="img" onChange={(e) => setFile(e.target.files[0])}/>

            <button onClick={handleUpload}>
            {uploading ? "uploading" : "Upload"}
              </button>

            <label htmlFor="">Description</label>
            <textarea 
            name="desc" 
            id="" cols="30" rows="16" 
            placeholder='Brief description about your service that you introduce to the customers'
            onChange={handleChange}
            ></textarea>
            
            <button onClick={handleSubmit}>Create</button>
          </div>
          <div className="right">
            <label htmlFor="">Service Title</label>
            <input type="text" name="shortTitle" placeholder='e.g HTML and CSS page' onChange={handleChange} />

            <label htmlFor="">Short Description</label>
            <textarea onChange={handleChange} name="shortDesc" id="" cols="30" rows="10" placeholder='short description for your service'></textarea>

            <label htmlFor="">Delivery Time</label>
            <input type="number" name="deliveryTime" min={1} onChange={handleChange}/>

            <label htmlFor="">Price</label>
            <input type="number" name="price" min={1} onChange={handleChange}/>


          </div>
        </div>
      </div>
    </div>
  )
}
