import Express from 'express';
import mongoose from 'mongoose';
import userRoute from './routes/user.route.js';
import gigRoute from './routes/gig.route.js'
import orderRoute from './routes/order.route.js'
import conversationRoute from './routes/conversation.route.js'
import messageRoute from './routes/message.route.js'
import authRoute from './routes/auth.route.js'
import heartRoute from './routes/heart.route.js'
import cookieParser from 'cookie-parser';  // to use cookies in the site
import cors from 'cors' //link site with api and send cookies
const app = Express();

mongoose.connect('mongodb://127.0.0.1:27017/IdealCode',{ useNewUrlParser: true }).then(()=>console.log('Connected to DB !!')).

catch(()=>console.log("Not Connected to DB :( "))
mongoose.set('strictQuery', false);


app.use(Express.json());
app.use(cookieParser());
app.use(Express.urlencoded({ extended: true }));
app.use(cors({
  origin:"http://localhost:5173",
  credentials:true,
  
}))

app.use("/api/auth",authRoute);
app.use("/api/users",userRoute);
app.use("/api/gigs",gigRoute);
app.use("/api/orders",orderRoute);
app.use("/api/conversations",conversationRoute);
app.use("/api/messages",messageRoute);
app.use("/api/heart",heartRoute);

app.use((err, req, res, next) => {
    const errorStatus = err.status || 500;
    const errorMessage = err.message || "Something went wrong!";
  
    return res.status(errorStatus).send(errorMessage);
  });

app.listen(3000,()=>{
    console.log('Server is Running')
})