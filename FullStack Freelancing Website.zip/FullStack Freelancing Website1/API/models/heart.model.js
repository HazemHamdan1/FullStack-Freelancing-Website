import mongoose from "mongoose";
const {Schema} = mongoose;
const heartSchema = new Schema({
   gigId:{
    type:String,
    required:true,
   },
   userId:{
    type:String,
    required:true
   }
  
},{
    timestamps:true //to save the created date and updated dates.
})

export default mongoose.model("Heart",heartSchema)



