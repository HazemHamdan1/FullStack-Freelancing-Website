import mongoose from "mongoose";
const {Schema} = mongoose;
const gigSchema = new Schema({
   userId:{
    type:String,
    required:true,
   },
   Title:{
    type:String,
    required:true,
   },
   desc:{
    type:String,
    required:true,
   },
   cat:{
    type:String,
    required:true,
   },
   price:{
    type:Number,
    required:true,
   },
   img:{
    type:String,
    required:false,
   },
   shortTitle:{
    type:String,
    required:true,
   },
   shortDesc:{
    type:String,
    required:true,
   },
   deliveryTime:{
    type:Number,
    required:true,
   },

},{
    timestamps:true //to save the created date and updated dates.
})

export default mongoose.model("Gig",gigSchema)



