import mongoose from "mongoose";
const {Schema} = mongoose;
const messSchema = new Schema({
   convId:{
    type:String,
    required:true,
   },
   userId:{
    type:String,
    required:true,
   },
   desc:{
    type:String,
    required:true,
   }, 
  
},{
    timestamps:true //to save the created date and updated dates.
})

export default mongoose.model("message",messSchema)



