import mongoose from "mongoose";
const {Schema} = mongoose;
const convSchema = new Schema({
   id:{
    type:String,
    required:true,
   },
   buyerId:{
    type:String,
    required:true,
   },
   sellerId:{
    type:String,
    required:true,
   },
   readBySeller:{
    type:Boolean,
    required:true,
   },
   readByBuyer:{
    type:Boolean,
    required:true,
   },
   lastMessage:{
    type:String,
    required:false,
   },
  
},{
    timestamps:true //to save the created date and updated dates.
})

export default mongoose.model("conversation",convSchema)



