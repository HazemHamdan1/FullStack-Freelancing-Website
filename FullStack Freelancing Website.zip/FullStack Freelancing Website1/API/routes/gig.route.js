import Express from 'express';
import { verifyToken } from '../middleware/jwt.js';
import {
    creatGig,
    deleteGig,
    getGig,
    getGigs
} from '../controllers/gig.controller.js'
const router = Express.Router();

router.post('/',verifyToken,creatGig)
router.delete('/:id',verifyToken,deleteGig)
router.get('/single/:id',getGig)
router.get('/',getGigs)

export default router;