import Express from 'express';
import { verifyToken } from '../middleware/jwt.js';
import {
    addHeart,
    getHearts
} from '../controllers/heart.controller.js'
const router = Express.Router();

router.post('/:id',verifyToken,addHeart)
router.get('/:gId',getHearts)

export default router;