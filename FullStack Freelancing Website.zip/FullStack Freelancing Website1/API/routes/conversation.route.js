import Express from 'express';
import {verifyToken} from "../middleware/jwt.js"
import {
    getConversations, 
    createConversations,
    getSingleConversation,
    updateConversation
} from '../controllers/conversation.controller.js'
const router = Express.Router();

router.get("/",verifyToken,getConversations);
router.post("/",verifyToken,createConversations);
router.get("/single/:id",verifyToken,getSingleConversation);
router.put("/:id",verifyToken,updateConversation);
export default router;