import Heart from '../models/heart.model.js'
import Gig from '../models/gig.model.js'
import createError from '../utils/createError.js'

export const addHeart = async(req,res,next)=>{

    const newHeart = new Heart({
        gigId: req.params.id,
        userId:req.userId ,
    })

    try{
        const savedHeart = await newHeart.save();
        res.status(201).send(savedHeart);
        }catch(err){
        next(err)
    }

};


export const getHearts = async(req,res,next)=>{
    try{
        const hearts = await Heart.find({gigId:req.params.gId})

        if (hearts.length === 0) {
            console.log("empty")
            return next(createError(404, "No Hearts :("));
        }
     
        console.log(hearts)
        res.status(200).send(hearts);
        
    }catch(err){
        next(err);
    }
};

