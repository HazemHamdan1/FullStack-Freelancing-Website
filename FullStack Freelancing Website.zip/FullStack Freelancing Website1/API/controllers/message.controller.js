import Message from "../models/message.model.js";
import Conversation from "../models/conversation.model.js";

export const createMessage=async(req,res,next)=>{
    try{
        const newMessage = new Message({
            convId:req.body.convId,
            userId:req.userId,
            desc:req.body.desc
        })
        const saveMessage = await newMessage.save();
        await Conversation.findOneAndUpdate({id:req.body.convId},{
            $set:{
                readBySeller:req.isSeller,
                readByBuyer:!req.isSeller,
                lastMessage:req.body.desc
            },
        },
        {new:true}
    )
        res.status(200).send(saveMessage)
    }catch(err){
        next(err);
    }
};

export const getMessages=async(req,res,next)=>{
    try{
        const messages = await Message.find({convId:req.params.id})
        res.status(200).send(messages);
    }catch(err){
        next(err);
    }
};