import User from '../models/user.model.js'

export const deleteUser=async(req,res)=>{
    const user = User.findById(req.params.id)

    await User.findByIdAndDelete(req.params.id)
        res.status(200).send('Deleted ')
        console.log('User deleted ')  
}
export const getUser=async(req,res)=>{
    const user = await User.findById(req.params.id)
    res.status(200).send(user)
}